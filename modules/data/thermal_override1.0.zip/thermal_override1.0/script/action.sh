#!/system/bin/sh

echo "█▓▒▒░░░ THERMAL OVERRIDE ░░░▒▒▓█"
sleep 1
echo ""
echo "        THERMAL OVERRIDE"
echo ""
sleep 2

echo "[ Initializing Thermal Override ]"
sleep 1

echo "[ Applying Thermal Status Override ]"
cmd thermalservice override-status 0 2>/dev/null

echo "[ Checking Thermal Service ]"
THERMAL_STATUS=$(cmd thermalservice dump 2>/dev/null | head -n 20)

if [ -n "$THERMAL_STATUS" ]; then
    echo "[ Thermal Service : DETECTED ]"
else
    echo "[ Thermal Service : UNKNOWN ]"
fi

sleep 1

echo ""
echo "█▓▒▒░░░ THERMAL OVERRIDE ░░░▒▒▓█"
echo "[ THERMAL OVERRIDE : ACTIVE ]"
echo "[ STATUS OVERRIDE : 0 ]"
echo ""
echo "Thermal status override applied."
echo "█▓▒▒░░░ OVERRIDE ENABLED ░░░▒▒▓█"