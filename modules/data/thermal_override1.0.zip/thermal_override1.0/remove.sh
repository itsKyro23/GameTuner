#!/system/bin/sh

echo "█▓▒▒░░░ THERMAL OVERRIDE RESET ░░░▒▒▓█"
sleep 1
echo ""
echo "        THERMAL OVERRIDE RESET"
echo ""
sleep 2

echo "[ Initializing Thermal Reset ]"
sleep 1

echo "[ Removing Thermal Status Override ]"
cmd thermalservice reset 2>/dev/null

sleep 1

echo ""
echo "█▓▒▒░░░ THERMAL OVERRIDE RESET ░░░▒▒▓█"
echo "[ THERMAL OVERRIDE : RESET ]"
echo "[ THERMAL STATUS  : DEFAULT ]"
echo ""
echo "Thermal status override has been reset."
echo "█▓▒▒░░░ THERMAL PROTECTION RESTORED ░░░▒▒▓█"