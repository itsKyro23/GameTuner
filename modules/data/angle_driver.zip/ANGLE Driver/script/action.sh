#!/system/bin/sh

BASE_DIR="$(dirname "$0")"
GAME_LIST="$BASE_DIR/gamelist.txt"
DRIVER="angle"

echo "========================================"
echo "        ANGLE DRIVER MULTI GAME        "
echo "========================================"
echo ""

if [ ! -f "$GAME_LIST" ]; then
    echo "[✖] gamelist.txt not found!"
    exit 1
fi

echo "[•] Scanning game list..."
echo ""

PKGS=""
VALUES=""
COUNT=0
SKIPPED=0

while IFS= read -r PACKAGE
do
    PACKAGE=$(echo "$PACKAGE" | xargs)

    if [ -z "$PACKAGE" ] || echo "$PACKAGE" | grep -q "^#"; then
        continue
    fi

    if pm list packages | grep -q "$PACKAGE"; then
        echo "[✔] Installed  : $PACKAGE"

        if [ -z "$PKGS" ]; then
            PKGS="$PACKAGE"
            VALUES="$DRIVER"
        else
            PKGS="$PKGS,$PACKAGE"
            VALUES="$VALUES,$DRIVER"
        fi

        COUNT=$((COUNT+1))
    else
        echo "[✖] Not found  : $PACKAGE"
        SKIPPED=$((SKIPPED+1))
    fi

done < "$GAME_LIST"

echo ""
echo "----------------------------------------"

if [ -z "$PKGS" ]; then
    echo "[!] No valid games detected."
    echo "----------------------------------------"
    exit 0
fi

settings put global angle_gl_driver_selection_pkgs "$PKGS"
settings put global angle_gl_driver_selection_values "$VALUES"

echo "[✓] ANGLE driver applied successfully!"
echo ""
echo "Applied  : $COUNT game(s)"
echo "Skipped  : $SKIPPED game(s)"
echo ""
echo "========================================"