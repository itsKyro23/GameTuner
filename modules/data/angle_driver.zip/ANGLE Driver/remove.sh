#!/system/bin/sh

MODULE_DIR="$(dirname "$0")"
GAME_LIST="$MODULE_DIR/script/gamelist.txt"

echo "========================================"
echo "     REMOVE LISTED ANGLE ENTRIES        "
echo "========================================"
echo ""

if [ ! -f "$GAME_LIST" ]; then
    echo "[✖] gamelist.txt not found!"
    exit 1
fi

CURRENT_PKGS=$(settings get global angle_gl_driver_selection_pkgs)

if [ -z "$CURRENT_PKGS" ] || [ "$CURRENT_PKGS" = "null" ]; then
    echo "[!] No ANGLE configuration found."
    exit 0
fi

NEW_LIST="$CURRENT_PKGS"
REMOVED=0

while IFS= read -r TARGET || [ -n "$TARGET" ]
do
    TARGET=$(echo "$TARGET" | xargs)

    if [ -z "$TARGET" ] || echo "$TARGET" | grep -q "^#"; then
        continue
    fi

    if echo "$NEW_LIST" | grep -q "$TARGET"; then
        echo "[✔] Removing : $TARGET"
        NEW_LIST=$(echo "$NEW_LIST" | sed "s/$TARGET//g" | sed 's/,,/,/g' | sed 's/^,//' | sed 's/,$//')
        REMOVED=$((REMOVED+1))
    fi

done < "$GAME_LIST"

if [ -z "$NEW_LIST" ]; then
    settings delete global angle_gl_driver_selection_pkgs
    settings delete global angle_gl_driver_selection_values
else
    settings put global angle_gl_driver_selection_pkgs "$NEW_LIST"
fi

echo ""
echo "----------------------------------------"
echo "[✓] Removal completed."
echo "Removed : $REMOVED game(s)"
echo ""
echo "========================================"