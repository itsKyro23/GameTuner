#!/system/bin/sh

echo "==============================="
echo "           GAME BOOSTER"
echo "==============================="
echo "[INFO] Restoring system settings..."

echo "[INFO] Disabling performance mode..."
cmd power set-fixed-performance-mode-enabled false

echo "[INFO] Resetting thermal service..."
cmd thermalservice reset

echo "[INFO] Restoring system animations..."
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

echo "[INFO] Restoring touch settings..."
settings put system pointer_speed 0

echo "[INFO] Restoring refresh rate..."
settings delete system peak_refresh_rate
settings delete system min_refresh_rate

echo "[INFO] Restoring rendering pipeline..."
setprop debug.hwui.renderer ""
setprop debug.sf.latch_unsignaled ""
setprop debug.sf.disable_backpressure ""

echo "[SUCCESS] Game Boost Disabled"
echo "==============================="