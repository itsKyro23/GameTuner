#!/system/bin/sh

echo "==============================="
echo "          GAME BOOSTER"
echo "==============================="
echo "[INFO] Activating performance mode..."

cmd power set-fixed-performance-mode-enabled true

echo "[INFO] Adjusting thermal service..."
cmd thermalservice override-status 0

echo "[INFO] Disabling system animations..."
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

echo "[INFO] Optimizing touch response..."
settings put system pointer_speed 7

echo "[INFO] Detecting supported refresh rate..."

DISPLAY_INFO=$(dumpsys display)

if echo "$DISPLAY_INFO" | grep -q "120"; then
    FPS=120
elif echo "$DISPLAY_INFO" | grep -q "90"; then
    FPS=90
elif echo "$DISPLAY_INFO" | grep -q "60"; then
    FPS=60
else
    FPS=60
fi

echo "[INFO] Setting refresh rate to ${FPS}Hz"

settings put system peak_refresh_rate $FPS
settings put system min_refresh_rate $FPS

echo "[INFO] Optimizing rendering pipeline..."
setprop debug.hwui.renderer skiagl
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1

echo "[SUCCESS] Game Boost Activated"
echo "[INFO] Refresh Rate: ${FPS}Hz"
echo "==============================="