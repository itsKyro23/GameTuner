#!/system/bin/sh

echo "==============================="
echo "          GAME BOOSTER"
echo "==============================="
echo "[INFO] Activating performance mode..."

cmd power set-fixed-performance-mode-enabled true

echo "[INFO] Adjusting thermal service..."
cmd thermalservice override-status 0

echo "[INFO] Disabling system animations..."
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

echo "[INFO] Optimizing rendering pipeline..."
setprop debug.hwui.renderer skiagl
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1

echo "[SUCCESS] Game Boost Activated"
echo "==============================="