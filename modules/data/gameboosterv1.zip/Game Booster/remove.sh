#!/system/bin/sh

echo "==============================="
echo "           GAME BOOSTER"
echo "==============================="
echo "[INFO] Restoring system settings..."

cmd power set-fixed-performance-mode-enabled false

echo "[INFO] Resetting thermal service..."
cmd thermalservice reset

echo "[INFO] Restoring system animations..."
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

echo "[SUCCESS] Game Boost Disabled"
echo "==============================="